from typing import List, Sequence, Callable
Vector = List[int]

# we will work on 16-dimensional vector space over the finite field of size 97
p = 97
d = 16


def int_to_vec(n: int) -> Vector:
    """Convert an integer to a vector in Fp^d."""
    assert 0 <= n < p**d
    return [(n // p**(d - 1 - i)) % p for i in range(d)]


def vec_to_int(v: Vector) -> int:
    """Convert a vector in Fp^d to an integer."""
    assert len(v) == d
    return sum(c * p**(d - 1 - i) for i, c in enumerate(v))


def int_to_vecs(n: int) -> List[Vector]:
    """Convert an integer to a list of vectors in Fp^d. `n` can be arbitrary
    large."""
    result = []
    while n > 0:
        result.append(int_to_vec(n % p**d))
        n //= p**d
    result.reverse()  # keep big-endian order
    return result


def vecs_to_int(vecs: List[Vector]) -> int:
    """Convert a list of vectors in Fp^d to an integer."""
    result = 0
    for v in vecs:
        result *= p**d
        result += vec_to_int(v)
    return result


# this is the result of `random.shuffle`. There's really nothing here, at least
# for the intended solution.
SBOX = (60, 79, 6, 71, 18, 64, 96, 76, 73, 36, 2, 68, 19, 38, 84, 33, 59, 1, 45, 44, 41, 49, 54, 28, 16, 48, 12, 52, 91, 14, 39, 24, 25, 69, 83, 51, 29, 7, 82, 26, 56, 17, 86, 27, 94, 20, 95, 58, 37, 55, 5, 11, 72, 4, 32, 23, 80, 88, 90, 8, 31, 42, 75, 57, 22, 87, 30, 47, 65, 53, 63, 0, 13, 10, 93, 77, 92, 70, 62, 78, 21, 66, 61, 34, 74, 46, 43, 40, 81, 67, 15, 85, 3, 35, 50, 9, 89)


def confuse(v: Vector, sbox: Sequence[int] = SBOX):
    """Substitute the components in `v` based on `sbox`."""
    assert len(v) == d
    for i in range(d):
        v[i] = sbox[v[i]]


# An upper triangular matrix is surely invertible when its diagonal elements
# are all non-zero. Also, small numbers help improve performance.
DMATRIX = (
    (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 8, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 0, 9, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 11, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 0, 0,  0,  0, 12, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 0, 0,  0,  0,  0, 13, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 0, 0,  0,  0,  0,  0, 14, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 0, 0,  0,  0,  0,  0,  0, 15, 16),
    (0, 0, 0, 0, 0, 0, 0, 0, 0,  0,  0,  0,  0,  0,  0, 16),
)


def diffuse(v: Vector, dmatrix: Sequence[Sequence[int]] = DMATRIX):
    """Left multiply `v` by `dmatrix`."""
    assert len(v) == d
    result = [0] * d
    for i in range(d):
        for j in range(d):
            result[i] = (result[i] + dmatrix[i][j] * v[j]) % p
    for i in range(d):
        v[i] = result[i]


def add_key(v1: Vector, v2: Vector):
    """Add two vectors together: `v1 += v2`."""
    for i in range(d):
        v1[i] = (v1[i] + v2[i]) % p


def encrypt_vec(v: Vector, k: Vector):
    """Encrypt `v`, using `k` as key."""
    for _ in range(10):
        add_key(v, k)
        confuse(v)
        diffuse(v)


def encrypt(plaintext: bytes, key: int,
            vef: Callable[[Vector, Vector], None] = encrypt_vec) -> bytes:
    """Wrapper of a vector encryption function `vef` to support binary
    input/output."""
    m = int.from_bytes(plaintext, "big")
    vecs = int_to_vecs(m)
    k = int_to_vec(key)
    for v in vecs:
        vef(v, k)
    c = vecs_to_int(vecs)
    return c.to_bytes((c.bit_length() + 7) // 8, "big")


if __name__ == '__main__':
    from secret import flag
    from random import randint
    print("len_flag =", len(flag))
    print("ciphertext =", encrypt(flag.encode(), randint(0, p**d - 1)))

# Output:
# len_flag = 46
# ciphertext = b' \x83\xfb\xd5\x94\xba\xa3\x7f\xac\x8b\xfa\xf0{\x1dW*\xccnP3\xc9M\xb3\x88\xd3W\x19H\x1a\xf8\x1c\xec\x8d\x12\x9d\x86o\xb4\xcfee&\t\xff\xdf\xab\xacQ@\xf3y9\xa5'
