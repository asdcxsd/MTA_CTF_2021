from interfaces import TokenProvider, EncryptionProvider, RandomnessProvider


class KMS:
    """
    Key management system. Its services include key import/generation and data
    encryption/decryption.

    The KMS is stateless, meaning that, it won't store keys. Instead, keys are
    embedded into key usage tokens, from which only the KMS knows how to
    extract the keys out. That's the reason why this KMS is secure despite the
    fact that keys are stored at the client side.
    """

    def __init__(self, tp: TokenProvider, ep: EncryptionProvider,
                 rp: RandomnessProvider):
        """Instantiating a KMS requires a token provider, an encryption
        provider and a randomness provider."""
        assert tp.get_key_size() == ep.get_key_size()
        self.key_size = tp.get_key_size()
        self.tp = tp
        self.ep = ep
        self.rp = rp

    def import_key(self, key: bytes) -> bytes:
        """Import a key, return its usage token."""
        assert len(key) == self.key_size, "invalid key size"
        return self.tp.generate_key_usage_token(key)

    def generate_key(self) -> bytes:
        """Generate a new key, return its usage token."""
        key = self.rp.get_random_bytes(self.key_size)
        return self.tp.generate_key_usage_token(key)

    def encrypt(self, token: bytes, plaintext: bytes) -> bytes:
        """Encrypt a plaintext with provided key usage token."""
        key = self.tp.extract_key_from_token(token)
        return self.ep.encrypt(key, plaintext)

    def decrypt(self, token: bytes, ciphertext: bytes) -> bytes:
        """Decrypt a ciphertext with provided key usage token."""
        key = self.tp.extract_key_from_token(token)
        return self.ep.decrypt(key, ciphertext)

    def is_valid(self, token: bytes, key: bytes) -> bool:
        """Verify if a token is valid for a given key."""
        return self.tp.extract_key_from_token(token) == key
