from interfaces import TokenProvider
from Crypto.Cipher.AES import new as AesCipher
from Crypto.Cipher.AES import MODE_GCM
from time import time


class Aes256GcmTP(TokenProvider):
    """A token provider implementation using AES256/CBC algorithm."""

    def __init__(self, secret: bytes):
        self.secret = secret
        self.last_timestamp = 0

    def get_key_size(self) -> int:
        return 32

    def get_token_size(self) -> int:
        return (
                + 12  # nonce
                + 32  # encrypted key
                + 16  # tag
        )

    def generate_key_usage_token(self, key: bytes) -> bytes:
        assert len(key) == self.get_key_size(), "unsupported key size"

        # this is the best way to avoid nonce reuse
        now = int(time())
        if now <= self.last_timestamp:
            now = self.last_timestamp + 1
        self.last_timestamp = now
        nonce = now.to_bytes(12, "big")

        cipher = AesCipher(self.secret, MODE_GCM, nonce)
        encrypted_key, tag = cipher.encrypt_and_digest(key)
        return nonce + encrypted_key + tag

    def extract_key_from_token(self, token: bytes) -> bytes:
        assert len(token) == self.get_token_size(), "invalid token"
        nonce = token[:12]
        encrypted_key = token[12:-16]
        tag = token[-16:]
        cipher = AesCipher(self.secret, MODE_GCM, nonce)
        return cipher.decrypt_and_verify(encrypted_key, tag)
