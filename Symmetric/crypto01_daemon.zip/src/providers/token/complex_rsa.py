from interfaces import TokenProvider, RandomnessProvider
from collections import namedtuple
from Crypto.Util.number import getPrime, inverse

Complex = namedtuple("Complex", ["re", "im"])


def complex_mult(c1, c2, modulus):
    return Complex(
        (c1.re * c2.re - c1.im * c2.im) % modulus,  # real part
        (c1.re * c2.im + c1.im * c2.re) % modulus,  # image part
    )


def complex_pow(c, exp, modulus):
    result = Complex(1, 0)
    while exp > 0:
        if exp & 1:
            result = complex_mult(result, c, modulus)
        c = complex_mult(c, c, modulus)
        exp >>= 1
    return result


def bytes_to_complex(s: bytes) -> Complex:
    assert len(s) % 2 == 0
    hl = len(s) // 2
    return Complex(re=int.from_bytes(s[:hl], "big"),
                   im=int.from_bytes(s[hl:], "big"))


def complex_to_bytes(c: Complex, length: int) -> bytes:
    return c.re.to_bytes(length // 2, "big") + c.im.to_bytes(length // 2,
                                                             "big")


class ComplexRsaTP(TokenProvider):
    """A token provider implementation using RSA algorithm applied to complex
    numbers over a finite ring."""

    def __init__(self, rp: RandomnessProvider):
        p = getPrime(512, rp.get_random_bytes)
        q = getPrime(512, rp.get_random_bytes)

        # small `d` will make `extract_key_from_token` faster
        d = getPrime(64, rp.get_random_bytes)
        e = inverse(d, (p ** 2 - 1) * (q ** 2 - 1))
        self.secret_params = (p * q, e, d)

    def get_key_size(self) -> int:
        return 32

    def get_token_size(self) -> int:
        return (
                512  # bit-length of p and q
                * 2  # approximate bit-length of p*q
                * 2  # real part and image part
                // 8  # 1 byte = 8 bits :)
        )

    def generate_key_usage_token(self, key: bytes) -> bytes:
        assert len(key) == self.get_key_size(), "unsupported key size"
        n, e, d = self.secret_params
        return complex_to_bytes(complex_pow(bytes_to_complex(key), e, n),
                                self.get_token_size())

    def extract_key_from_token(self, token: bytes) -> bytes:
        assert len(token) == self.get_token_size(), "invalid token"
        n, e, d = self.secret_params
        return complex_to_bytes(complex_pow(bytes_to_complex(token), d, n),
                                self.get_key_size())
