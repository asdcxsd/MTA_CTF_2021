from interfaces import EncryptionProvider, RandomnessProvider
from Crypto.Cipher import ChaCha20


class ChachaEP(EncryptionProvider):
    """An encryption provider implementation using AES256/CBC algorithm."""

    def __init__(self, rp: RandomnessProvider):
        self.rp = rp

    def get_key_size(self) -> int:
        return ChaCha20.key_size

    def encrypt(self, key: bytes, plaintext: bytes) -> bytes:
        nonce = self.rp.get_random_bytes(12)
        cipher = ChaCha20.new(key=key, nonce=nonce)
        return nonce + cipher.encrypt(plaintext)

    def decrypt(self, key: bytes, ciphertext: bytes) -> bytes:
        nonce = ciphertext[:12]
        ciphertext = ciphertext[12:]
        cipher = ChaCha20.new(key=key, nonce=nonce)
        return cipher.decrypt(ciphertext)
