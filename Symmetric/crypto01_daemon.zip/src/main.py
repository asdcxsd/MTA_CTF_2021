import json
from kms import KMS
from providers.token.aes256_cbc import Aes256CbcTP
from providers.token.aes256_gcm import Aes256GcmTP
from providers.token.complex_rsa import ComplexRsaTP
from providers.encryption.chacha import ChachaEP
from providers.randomness.mersenne import MersenneTwisterRP


def main():
    rp = MersenneTwisterRP()
    ep = ChachaEP(rp)

    # Please choose an algorithm for the token provider
    # 1 -> Aes256Cbc
    # 2 -> Aes256Gcm
    # 3 -> ComplexRsa
    choice = int(input())
    if choice == 1:
        tp = Aes256CbcTP(rp)
    elif choice == 2:
        with open("/opt/flag/secret", "rb") as f:
            tp = Aes256GcmTP(f.read())
    elif choice == 3:
        tp = ComplexRsaTP(rp)
    else:
        assert False, "Unknown algorithm"

    kms = KMS(tp, ep, rp)

    req_lim = 3000  # the limit number of requests
    key_imp_lim = 5  # the limit number of imported keys
    target = bytes.fromhex(
        "2020" * (kms.key_size // 2))  # the token forgery target

    keys_imported = 0
    for _ in range(req_lim):
        try:
            # All requests/responses are in JSON format
            req = json.loads(input())
            if req["action"] == "import_key":
                key = bytes.fromhex(req["key"])
                assert keys_imported < key_imp_lim, "cannot import more keys"
                assert key != target, "cannot import this key"
                token = kms.import_key(key)
                print(json.dumps({
                    "token": token.hex()
                }))
                keys_imported += 1

            elif req["action"] == "generate_key":
                token = kms.generate_key()
                print(json.dumps({
                    "token": token.hex()
                }))

            elif req["action"] == "encrypt":
                token = bytes.fromhex(req["token"])
                plaintext = bytes.fromhex(req["plaintext"])
                ciphertext = kms.encrypt(token, plaintext)
                print(json.dumps({
                    "ciphertext": ciphertext.hex()
                }))

            elif req["action"] == "decrypt":
                token = bytes.fromhex(req["token"])
                ciphertext = bytes.fromhex(req["ciphertext"])
                plaintext = kms.decrypt(token, ciphertext)
                print(json.dumps({
                    "plaintext": plaintext.hex()
                }))

            elif req["action"] == "report_bug":
                # Only the KMS is able to generate a valid key usage token for
                # a specific key. If you can disprove this, we will give you a
                # special bounty.
                token = bytes.fromhex(req["token"])
                assert kms.is_valid(token, target), "invalid token"
                with open("/opt/flag/flag.txt", "rb") as f:
                    bounty = int.from_bytes(f.read(), "big")
                print(json.dumps({"bounty": bounty}))

            else:
                assert False, "invalid action"

        except Exception as err:
            print(json.dumps({"error": str(err)}))


if __name__ == '__main__':
    main()
